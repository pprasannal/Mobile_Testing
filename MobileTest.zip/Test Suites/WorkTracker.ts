<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>WorkTracker</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>941953b3-bb3c-4a42-b8d7-00389e3d9f2c</testSuiteGuid>
   <testCaseLink>
      <guid>b747c111-f647-4a5f-a7b3-99bb70031025</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CreateTaskTime</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5a7ef388-ab31-4e84-afb9-ee3bb3a6d889</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VerifyTaskTime</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fee58d6e-851b-4454-9d87-03cd5983fa75</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DeleteTaskTime</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
